import numpy as np
import os
import scipy.sparse as sparse

from source import utils_mp
from source import utils_eval
from source import utils_files


def cartesian_dist(vec_x: np.array, vec_y: np.array, axis=1) -> np.ndarray:
    dist = np.linalg.norm(vec_x - vec_y, axis=axis)
    return dist


# https://stackoverflow.com/questions/4116658/faster-numpy-cartesian-to-spherical-coordinate-conversion
def cart2polar(xyz):
    pts_new = np.zeros_like(xyz)
    xy = xyz[:, 0]**2 + xyz[:, 1]**2
    pts_new[:, 0] = np.sqrt(xy + xyz[:, 2]**2)
    pts_new[:, 1] = np.arctan2(np.sqrt(xy), xyz[:, 2])  # for elevation angle defined from Z-axis down
    # ptsnew[:, 1] = np.arctan2(xyz[:,2], np.sqrt(xy))  # for elevation angle defined from XY-plane up
    pts_new[:, 2] = np.arctan2(xyz[:, 1], xyz[:, 0])
    return pts_new


# https://stackoverflow.com/questions/48348953/spherical-polar-co-ordinate-to-cartesian-co-ordinate-conversion
def polar2cart(r, theta, phi):
    return [
         r * np.sin(theta) * np.cos(phi),
         r * np.sin(theta) * np.sin(phi),
         r * np.cos(theta)
    ]


def batch_quat_to_rotmat(q, out=None):
    """
    quaternion a + bi + cj + dk should be given in the form [a,b,c,d]
    :param q:
    :param out:
    :return:
    """

    import torch

    batchsize = q.size(0)

    if out is None:
        out = q.new_empty(batchsize, 3, 3)

    # 2 / squared quaternion 2-norm
    s = 2 / torch.sum(q.pow(2), 1)

    # coefficients of the Hamilton product of the quaternion with itself
    h = torch.bmm(q.unsqueeze(2), q.unsqueeze(1))

    out[:, 0, 0] = 1 - (h[:, 2, 2] + h[:, 3, 3]).mul(s)
    out[:, 0, 1] = (h[:, 1, 2] - h[:, 3, 0]).mul(s)
    out[:, 0, 2] = (h[:, 1, 3] + h[:, 2, 0]).mul(s)

    out[:, 1, 0] = (h[:, 1, 2] + h[:, 3, 0]).mul(s)
    out[:, 1, 1] = 1 - (h[:, 1, 1] + h[:, 3, 3]).mul(s)
    out[:, 1, 2] = (h[:, 2, 3] - h[:, 1, 0]).mul(s)

    out[:, 2, 0] = (h[:, 1, 3] - h[:, 2, 0]).mul(s)
    out[:, 2, 1] = (h[:, 2, 3] + h[:, 1, 0]).mul(s)
    out[:, 2, 2] = 1 - (h[:, 1, 1] + h[:, 2, 2]).mul(s)

    return out


def cos_angle(v1, v2):
    import torch
    return torch.bmm(v1.unsqueeze(1),
                     v2.unsqueeze(2)).view(-1) / torch.clamp(v1.norm(2, 1) * v2.norm(2, 1), min=0.000001)


def lerp(v1, v2, factor):
    return v1 * factor + v2 * (1.0 - factor)


def is_matrix_symmetric(matrix):
    return (matrix != matrix.transpose()).count_nonzero() == 0


# Assumption: Zero-values mean that the value is unknown
# Values may appear only in one triangle of the matrix
# make symmetric by taking single values if they exist
# average upper and lower triangles
def make_matrix_symmetric(mat, disconnected_heuristic=False, probably_accurate_distance_factor_threshold=0.8):
    """
    Try to make matrix symmetric. Values from the upper and lower triangle are compared and different cases handled.
    0/x -> x
    x/y -> (x+y)/2
    if disconnected_heuristic:
        -1/x if x >= t -> -1
        -1/x if x < t -> x
        where t is a threshold for the inner areas of patches
    :param mat:
    :param disconnected_heuristic:
    :param: probably_accurate_distance_factor_threshold
    :return:
    """

    # NOTE: sparse matrices don't support logical operations

    # split matrix in diagonal and triangles
    mat_upper = sparse.triu(mat, k=1).tocsr()
    mat_lower = sparse.tril(mat, k=-1).tocsc()
    mat_diag = mat.diagonal()

    # transpose lower triangle to make it compatible with the upper
    mat_lower = mat_lower.transpose()

    # check which values to keep
    mat_upper_has_value = (mat_upper != 0.0).astype(np.int)
    mat_lower_has_value = (mat_lower != 0.0).astype(np.int)
    take_upper_values = ((mat_upper_has_value * 2 + mat_lower_has_value) == 2)
    take_lower_values = ((mat_upper_has_value + mat_lower_has_value * 2) == 2)
    take_avg_values = ((mat_upper_has_value + mat_lower_has_value) == 2)
    print('Trying to resolve {} asymmetric values.'.format((mat_upper != mat_lower).nnz))

    # handle connected / disconnected
    if disconnected_heuristic:
        mat_upper_disconnected = (mat_upper < 0.0).astype(np.int)
        mat_lower_disconnected = (mat_lower < 0.0).astype(np.int)
        mat_upper_connected = (mat_upper > 0.0).astype(np.int)
        mat_lower_connected = (mat_lower > 0.0).astype(np.int)
        mat_up_down_conflict = (mat_upper_connected.astype(int) + mat_lower_disconnected.astype(int)) == 2
        mat_down_up_conflict = (mat_lower_connected.astype(int) + mat_upper_disconnected.astype(int)) == 2
        mat_conflicting = (mat_up_down_conflict.astype(int) + mat_down_up_conflict.astype(int)) > 0
        print("Making matrix symmetric using heuristic. "
              "Trying to resolve {} conflicting values.".format(mat_conflicting.nnz))
        if mat_conflicting.nnz > 0:

            # values that are in the inner area of the patches are probably accurate
            # max_per_patch = mat.max(axis=1)
            upper_max_per_patch = mat.max(axis=1)
            lower_max_per_patch = mat.max(axis=0).transpose()
            both_max_per_patch = sparse.hstack([upper_max_per_patch, lower_max_per_patch])
            max_per_patch = both_max_per_patch.max(axis=1).tocsr()
            confidence_threshold_per_patch = max_per_patch * probably_accurate_distance_factor_threshold
            # print("conf thresh pp ", confidence_threshold_per_patch.data)

            # find values of upper triangle that are probably correct
            only_upper_connected = (mat_upper_connected.astype(int) + mat_lower_disconnected.astype(int)) == 2
            mat_conflicting_nz = mat_conflicting.nonzero()
            confidence_thresholds = confidence_threshold_per_patch[mat_conflicting_nz[0], np.zeros(mat_conflicting_nz[0].shape[0])].A[0]
            confidence_thresholds_sparse = sparse.coo_matrix((confidence_thresholds, (mat_conflicting_nz[0], mat_conflicting_nz[1])), mat_upper.shape)
            upper_confident = mat_upper < confidence_thresholds_sparse
            upper_inconfident = mat_upper > confidence_thresholds_sparse
            upper_confident_connected = (only_upper_connected.astype(int) + upper_confident.astype(int)) == 2
            upper_confident_disconnected = (only_upper_connected.astype(int) + upper_inconfident.astype(int)) == 2

            # find values of lower triangle that are probably correct
            only_lower_connected = (mat_lower_connected.astype(int) + mat_upper_disconnected.astype(int)) == 2
            mat_lower_nz = mat_lower.nonzero()
            lower_relevant_threshold = confidence_threshold_per_patch[mat_lower_nz[0], np.zeros(mat_lower_nz[0].shape[0])].A[0]
            lower_relevant_threshold_sparse = sparse.coo_matrix((lower_relevant_threshold, (mat_lower_nz[0], mat_lower_nz[1])), mat_lower.shape)
            lower_confident = mat_lower < confidence_thresholds_sparse
            lower_inconfident = mat_lower > lower_relevant_threshold_sparse
            lower_confident_connected = (only_lower_connected.astype(int) + lower_confident.astype(int)) == 2
            lower_confident_disconnected = (only_lower_connected.astype(int) + lower_inconfident.astype(int)) == 2
            print("Replacing {} disconnected and {} connected values".format(
                upper_confident_disconnected.nnz + lower_confident_disconnected.nnz,
                upper_confident_connected.nnz + lower_confident_connected.nnz))

            # keep confidently connected and disconnected
            upper_confident_con_discon = (upper_confident_connected.astype(int) + lower_confident_disconnected.astype(int)) >= 1
            lower_confident_con_discon = (lower_confident_connected.astype(int) + upper_confident_disconnected.astype(int)) >= 1

            keep_upper = (upper_confident_con_discon.astype(int) + mat_conflicting.astype(int)) == 2
            keep_lower = (lower_confident_con_discon.astype(int) + mat_conflicting.astype(int)) == 2

            # average only when both are connected
            take_avg_values = (mat_upper_connected.astype(int) + mat_lower_connected.astype(int)) == 2

    # assemble new matrix
    mat_new = sparse.lil_matrix(mat.shape, dtype=mat.dtype)
    if take_upper_values.count_nonzero() != 0:
        mat_new[take_upper_values] += mat_upper[take_upper_values]
    if take_lower_values.count_nonzero() != 0:
        mat_new[take_lower_values] += mat_lower[take_lower_values]

    if take_avg_values.count_nonzero() != 0:
        # if there is a type error here, you need to cast the matrix to float before calling
        mat_new[take_avg_values] += (mat_upper[take_avg_values] + mat_lower[take_avg_values]) * 0.5

    if disconnected_heuristic and mat_conflicting.nnz > 0:
        if keep_upper.count_nonzero() != 0:
            mat_new[keep_upper] += mat_upper[keep_upper]
        if keep_lower.count_nonzero() != 0:
            mat_new[keep_lower] += mat_lower[keep_lower]

    mat_new += mat_new.transpose()  # finally copy upper triangle down
    mat_new.setdiag(mat_diag)

    return mat_new.tocsr()


def right_handed_to_left_handed(pts: np.ndarray):
    pts_res = np.zeros_like(pts)
    if pts.shape[0] > 0:
        pts_res[:, 0] = pts[:, 0]
        pts_res[:, 1] = -pts[:, 2]
        pts_res[:, 2] = pts[:, 1]
    return pts_res


def get_patch_radii(pts_patch: np.array, query_pts: np.array):
    if pts_patch.shape == query_pts.shape:
        patch_radius = np.linalg.norm(pts_patch - query_pts, axis=0)
    else:
        dist = cartesian_dist(np.repeat(np.expand_dims(query_pts, axis=0), pts_patch.shape[0], axis=0),
                              pts_patch, axis=1)
        patch_radius = np.max(dist, axis=0)
    return patch_radius


def model_space_to_patch_space_single_point(
        pts_to_convert_ms: np.array, pts_patch_center_ms: np.array, patch_radius_ms):

    pts_patch_space = pts_to_convert_ms - pts_patch_center_ms
    pts_patch_space = pts_patch_space / patch_radius_ms
    return pts_patch_space


def model_space_to_patch_space(
        pts_to_convert_ms: np.array, pts_patch_center_ms: np.array, patch_radius_ms: float):

    pts_patch_center_ms_repeated = \
        np.repeat(np.expand_dims(pts_patch_center_ms, axis=0), pts_to_convert_ms.shape[-2], axis=-2)
    pts_patch_space = pts_to_convert_ms - pts_patch_center_ms_repeated
    pts_patch_space = pts_patch_space / patch_radius_ms

    return pts_patch_space


def patch_space_to_model_space_single_point(
        pts_to_convert_ps: np.array, pts_patch_center_ms: np.array, patch_radius_ms):

    pts_model_space = pts_to_convert_ps * \
                      np.repeat(np.expand_dims(patch_radius_ms, axis=0), pts_to_convert_ps.shape[0], axis=0)
    pts_model_space = pts_model_space + pts_patch_center_ms
    return pts_model_space


def patch_space_to_model_space(
        pts_to_convert_ps: np.array, pts_patch_center_ms: np.array, patch_radius_ms):

    pts_model_space = pts_to_convert_ps * \
                      np.repeat(np.expand_dims(patch_radius_ms, axis=1), pts_to_convert_ps.shape[1], axis=1)
    pts_model_space = pts_model_space + pts_patch_center_ms
    return pts_model_space


def _get_pts_normals_single_file(pts_file_in, mesh_file_in,
                                 normals_file_out, pts_normals_file_out,
                                 samples_per_model=10000):

    import trimesh.sample
    import sys
    import scipy.spatial as spatial
    from source import point_cloud

    # sample points on the surface and take face normal
    pts = np.load(pts_file_in)
    mesh = trimesh.load(mesh_file_in)
    samples, face_ids = trimesh.sample.sample_surface(mesh, samples_per_model)
    mesh.fix_normals()

    # get the normal of the closest sample for each point in the point cloud
    # otherwise KDTree construction may run out of recursions
    leaf_size = 100
    sys.setrecursionlimit(int(max(1000, round(samples.shape[0] / leaf_size))))
    kdtree = spatial.cKDTree(samples, leaf_size)
    pts_dists, sample_ids = kdtree.query(x=pts, k=1)
    face_ids_for_pts = face_ids[sample_ids]
    pts_normals = mesh.face_normals[face_ids_for_pts]

    np.save(normals_file_out, pts_normals)
    point_cloud.write_xyz(pts_normals_file_out, pts, normals=pts_normals)


def get_pts_normals(base_dir, dataset_dir, dir_in_pointcloud,
                    dir_in_meshes, dir_out_normals, samples_per_model=10000, num_processes=1):

    dir_in_pts_abs = os.path.join(base_dir, dataset_dir, dir_in_pointcloud)
    dir_in_meshes_abs = os.path.join(base_dir, dataset_dir, dir_in_meshes)
    dir_out_normals_abs = os.path.join(base_dir, dataset_dir, dir_out_normals)
    dir_out_pts_normals_abs = os.path.join(base_dir, dataset_dir, dir_out_normals, 'pts')

    os.makedirs(dir_out_normals_abs, exist_ok=True)
    os.makedirs(dir_out_pts_normals_abs, exist_ok=True)

    pts_files = [f for f in os.listdir(dir_in_pts_abs)
                 if os.path.isfile(os.path.join(dir_in_pts_abs, f)) and f[-4:] == '.npy']
    files_in_pts_abs = [os.path.join(dir_in_pts_abs, f) for f in pts_files]
    files_in_meshes_abs = [os.path.join(dir_in_meshes_abs, f[:-8] + '.ply') for f in pts_files]
    files_out_normals_abs = [os.path.join(dir_out_normals_abs, f) for f in pts_files]
    files_out_pts_normals_abs = [os.path.join(dir_out_pts_normals_abs, f[:-8] + '.xyz') for f in pts_files]

    calls = []
    for fi, f in enumerate(pts_files):
        # skip if result already exists and is newer than the input
        if utils_files.call_necessary([files_in_pts_abs[fi], files_in_meshes_abs[fi]],
                                      [files_out_normals_abs[fi], files_out_pts_normals_abs[fi]]):
            calls.append((files_in_pts_abs[fi], files_in_meshes_abs[fi],
                          files_out_normals_abs[fi], files_out_pts_normals_abs[fi],
                          samples_per_model))

    utils_mp.start_process_pool(_get_pts_normals_single_file, calls, num_processes)


def _get_dist_from_patch_planes_single_file(file_in_pts_abs, file_in_normals_abs,
                                            file_in_pids_abs, file_in_query_abs,
                                            file_out_dists_abs, num_query_points_per_patch):

    from trimesh.points import point_plane_distance

    pts = np.load(file_in_pts_abs)
    normals = np.load(file_in_normals_abs)
    pids = np.load(file_in_pids_abs)
    query = np.load(file_in_query_abs)

    patch_pts = pts[pids]
    patch_normals = normals[pids]
    #patch_normals_avg = np.mean(patch_normals, axis=1)
    patch_center_normal = patch_normals[:, 0]
    patch_centers = np.mean(patch_pts, axis=1)

    dists = np.zeros(query.shape[0])
    for pi in range(pids.shape[0]):
        query_points_id_start = pi * num_query_points_per_patch
        query_points_id_end = (pi + 1) * num_query_points_per_patch
        patch_dists = point_plane_distance(
            points=query[query_points_id_start:query_points_id_end],
            #plane_normal=patch_normals_avg[pi],
            plane_normal=patch_center_normal[pi],
            plane_origin=patch_centers[pi])
        patch_dists[np.isnan(patch_dists)] = 0.0
        dists[query_points_id_start:query_points_id_end] = patch_dists
    np.save(file_out_dists_abs, dists)


def get_dist_from_patch_planes(base_dir, dataset_dir,
                               dir_in_pointcloud, dir_in_normals, dir_in_pids, dir_in_query,
                               dir_out_dists, num_query_points_per_patch, num_processes):

    dir_in_pts_abs = os.path.join(base_dir, dataset_dir, dir_in_pointcloud)
    dir_in_normals_abs = os.path.join(base_dir, dataset_dir, dir_in_normals)
    dir_in_pids_abs = os.path.join(base_dir, dataset_dir, dir_in_pids)
    dir_in_query_abs = os.path.join(base_dir, dataset_dir, dir_in_query)
    dir_out_dists_abs = os.path.join(base_dir, dataset_dir, dir_out_dists)

    os.makedirs(dir_out_dists_abs, exist_ok=True)

    pts_files = [f for f in os.listdir(dir_in_pts_abs)
                 if os.path.isfile(os.path.join(dir_in_pts_abs, f)) and f[-4:] == '.npy']
    files_in_pts_abs = [os.path.join(dir_in_pts_abs, f) for f in pts_files]
    files_in_normals_abs = [os.path.join(dir_in_normals_abs, f) for f in pts_files]
    file_in_pids_abs = [os.path.join(dir_in_pids_abs, f) for f in pts_files]
    file_in_query_abs = [os.path.join(dir_in_query_abs, f) for f in pts_files]
    files_out_dists_abs = [os.path.join(dir_out_dists_abs, f) for f in pts_files]

    calls = []
    for fi, f in enumerate(pts_files):
        # skip if result already exists and is newer than the input
        if utils_files.call_necessary([files_in_pts_abs[fi], files_in_normals_abs[fi],
                                       file_in_pids_abs[fi], file_in_query_abs[fi]],
                                      [files_out_dists_abs[fi]]):
            calls.append((files_in_pts_abs[fi], files_in_normals_abs[fi],
                          file_in_pids_abs[fi], file_in_query_abs[fi],
                          files_out_dists_abs[fi], num_query_points_per_patch))

    utils_mp.start_process_pool(_get_dist_from_patch_planes_single_file, calls, num_processes)


def get_point_cloud_sub_sample(sub_sample_size, pts_ms, query_point_ms, uniform=False):
    # take random subsample from point cloud
    if pts_ms.shape[0] >= sub_sample_size:
        # np.random.seed(42)  # test if the random subset causes the irregularities
        def dist_prob():  # probability decreasing with distance from query point
            query_pts = np.broadcast_to(query_point_ms, pts_ms.shape)
            dist = cartesian_dist(query_pts, pts_ms)
            dist_normalized = dist / np.max(dist)
            prob = 1.0 - 1.5 * dist_normalized  # linear falloff
            # prob = 1.0 - 2.0 * np.sin(dist_normalized * np.pi / 2.0)  # faster falloff
            prob_clipped = np.clip(prob, 0.05, 1.0)  # ensure that the probability is (eps..1.0)
            prob_normalized = prob_clipped / np.sum(prob_clipped)
            return prob_normalized

        if uniform:
            # basically choice
            # with replacement for better performance, shouldn't hurt with large point clouds
            sub_sample_ids = np.random.randint(low=0, high=pts_ms.shape[0], size=sub_sample_size)
        else:
            prob = dist_prob()
            sub_sample_ids = np.random.choice(pts_ms.shape[0], size=sub_sample_size, replace=False, p=prob)
        pts_sub_sample_ms = pts_ms[sub_sample_ids, :]
    # if not enough take shuffled point cloud and fill with zeros
    else:
        pts_shuffled = pts_ms[:, :3]
        np.random.shuffle(pts_shuffled)
        zeros_padding = np.zeros((sub_sample_size - pts_ms.shape[0], 3), dtype=np.float32)
        pts_sub_sample_ms = np.concatenate((pts_shuffled, zeros_padding), axis=0)
    return pts_sub_sample_ms


def _unit_test_comp_predictions():

    gt = np.array([1, 1, 1, 0, 0, 0, -1, -1, -1])
    pred = np.array([1, 0, -1, 0, 1, -1, -1, 1, 0])
    #gt =   np.array([1, 1, 1, -1, -1, -1])
    #pred = np.array([1, -1, 1, -1, -1, -1])
    #gt =   np.array([1, 1, 1, 1, 1, 1])
    #pred = np.array([1, 1, 1, 1, 1, 1])
    #gt =   np.array([-1])
    #pred = np.array([-1])
    #gt =   np.array([-1])
    #pred = np.array([1])
    #geodesic_mat_gt = sparse.csr_matrix(gt_arr_test, dtype=int)
    #geodesic_mat_pred = sparse.csr_matrix(pr_arr_test, dtype=int)
    #geodesic_mat_gt.prune()
    #geodesic_mat_pred.prune()

    results = utils_eval.compare_predictions_multi_class(gt, pred, 'test')

    utils_eval.print_list_of_dicts(results)

    return 0


def _unit_test_make_matrix_symmetric():

    # without heuristic
    m = np.array([[0.0,  0.0, -1.0,  0.0],
                  [1.0, -1.0, -1.0, -1.0],
                  [0.0,  2.0,  5.0,  0.0],
                  [0.0,  0.5,  0.0,  1.0]])

    m_sym = make_matrix_symmetric(sparse.csr_matrix(m)).todense().A

    m_gt = np.array([[ 0.0,  1.0, -1.0,  0.0],
                     [ 1.0, -1.0,  0.5, -0.25],
                     [-1.0,  0.5,  5.0,  0.0],
                     [ 0.0, -0.25,  0.0,  1.0]])

    if not (m_sym == m_gt).all():
        print('input \n', m)
        print('output \n', m_sym)
        print('expected output \n', m_gt)

    # with heuristic
    m = np.array([[0.0,  0.0, -1.0,  0.0],
                  [1.0, -1.0, -1.0,  6.0],
                  [0.0,  4.0,  5.0,  1.5],
                  [0.0,  2.0, -1.0,  1.0]])

    m_sym = make_matrix_symmetric(sparse.csr_matrix(m), disconnected_heuristic=True).todense().A

    m_gt = np.array([[ 0.0,  1.0,  -1.0,  0.0],
                     [ 1.0, -1.0,  -1.0,  4.0],
                     [-1.0, -1.0,   5.0,  1.5],
                     [ 0.0,  4.0,   1.5,  1.0]])

    if not (m_sym == m_gt).all():
        print('input \n', m)
        print('output \n', m_sym)
        print('expected output \n', m_gt)


