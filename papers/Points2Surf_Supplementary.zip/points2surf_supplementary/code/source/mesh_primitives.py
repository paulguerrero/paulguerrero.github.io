import numpy as np
from source import utils


def make_patch(sampling_dist: float,
               plane_dist: float,
               rnd_state: np.random.RandomState,
               cell_freedom=1.0)\
        -> (np.array, np.array):
    """
    sample 2 planes with stratified grids and return the plane index of the points
    inputs:
    - sampling_dist: float, mean distance between points
    - plane_dist: float, distance between planes
    - rnd_state: numpy.random.RandomState, seed for random sampling
    - cell_freedom: float, [0..1] limit the area of each grid cell in which the point can be sampled
    return:
    - points: np.array((n, 3))
    - plane_index: np.array((n), np.int)
    """

    plane_params_center = np.array([0, 1, 0, 0])
    plane_params_other = np.array([0, 1, 0, plane_dist])

    plane_points_center = sample_plane(sampling_dist=sampling_dist, plane_params=plane_params_center,
                                       rnd_state=rnd_state, cell_freedom=cell_freedom)
    plane_points_other = sample_plane(sampling_dist=sampling_dist, plane_params=plane_params_other,
                                      rnd_state=rnd_state, cell_freedom=cell_freedom)

    points = np.append(plane_points_center, plane_points_other, axis=0)

    plane_index = np.zeros((points.shape[0]), dtype=np.int)
    plane_index[:plane_points_center.shape[0]] = 0
    plane_index[plane_points_center.shape[0]:] = 1

    # sort points by distance to patch center
    origin_bc = np.broadcast_to(np.array([0, 0, 0]), points.shape)
    point_dists = utils.cartesian_dist(points, origin_bc)
    indices_sort = np.argsort(point_dists, axis=0)
    points = points[indices_sort, :]
    plane_index = plane_index[indices_sort]

    return points, plane_index


def sample_plane(
        sampling_dist: float,
        plane_params: np.array,
        rnd_state=np.random.RandomState(),
        cell_freedom=1.0)\
        -> np.array:
    """
    sample plane with a stratified grid in a unit sphere
    inputs:
    - sampling_dist: float, mean distance between points
    - plane_params: np.array, numpy array of shape (4) containing the Hessian normal form of a plane
    - rnd_state: np.random.RandomState, make things deterministic
    - cell_freedom: float, [0..1] limit the area of each grid cell in which the point can be sampled
    return:
    - points: np.array(n, 3)
    """

    # get orthonormal frame
    normal_plane = plane_params[:3]
    normal_plane = normal_plane / np.linalg.norm(normal_plane)
    if np.all(normal_plane == np.array([1, 0, 0])):
        dir_random = np.array([0, 1, 0])
    else:
        dir_random = np.array([1, 0, 0])
    orthogonal_a = np.cross(normal_plane, dir_random)
    orthogonal_a = orthogonal_a / np.linalg.norm(orthogonal_a)
    orthogonal_b = np.cross(normal_plane, orthogonal_a)
    orthogonal_b = orthogonal_b / np.linalg.norm(orthogonal_b)

    # get plane center
    normal_factor = plane_params[3] / plane_params[1]  # where y goes through 0
    center_plane = plane_params[:3] * normal_factor

    # get regular grid
    import math
    num_grind_cells_1d = math.ceil(1.0 / sampling_dist)
    x = np.linspace(-1.0, 1.0, num=num_grind_cells_1d)
    xx, yy = np.meshgrid(x, x)

    # get grid cell
    grid_cell_border_lower_x, grid_cell_border_lower_y = np.meshgrid(x[:-1], x[:-1])
    grid_cell_border_upper_x, grid_cell_border_upper_y = np.meshgrid(x[1:], x[1:])
    grid_cell_border_lower_flat_x = grid_cell_border_lower_x.flatten()
    grid_cell_border_upper_flat_x = grid_cell_border_upper_x.flatten()
    grid_cell_border_lower_flat_y = grid_cell_border_lower_y.flatten()
    grid_cell_border_upper_flat_y = grid_cell_border_upper_y.flatten()

    # limit freedom within cells
    def limit_cells(cell_lower, cell_upper, cell_freedom):
        cell_size = cell_upper - cell_lower
        cell_freedom_factor = 1.0 - cell_freedom
        cell_lower_new = cell_lower + (cell_freedom_factor * 0.5) * cell_size
        cell_upper_new = cell_upper - (cell_freedom_factor * 0.5) * cell_size
        return cell_lower_new, cell_upper_new
    grid_cell_border_lower_flat_x, grid_cell_border_upper_flat_x = \
        limit_cells(grid_cell_border_lower_flat_x, grid_cell_border_upper_flat_x, cell_freedom)
    grid_cell_border_lower_flat_y, grid_cell_border_upper_flat_y = \
        limit_cells(grid_cell_border_lower_flat_y, grid_cell_border_upper_flat_y, cell_freedom)

    # perform stratified sampling on grid
    grid_samples_dir_factor_x = rnd_state.uniform(grid_cell_border_lower_flat_x, grid_cell_border_upper_flat_x)
    grid_samples_dir_factor_y = rnd_state.uniform(grid_cell_border_lower_flat_y, grid_cell_border_upper_flat_y)

    # assemble points
    grid_samples_dir_factor_x_bc = np.repeat(np.expand_dims(grid_samples_dir_factor_x, 1), 3, axis=1)
    grid_samples_dir_factor_y_bc = np.repeat(np.expand_dims(grid_samples_dir_factor_y, 1), 3, axis=1)
    grid_samples_x = grid_samples_dir_factor_x_bc * np.expand_dims(orthogonal_a, axis=0)
    grid_samples_y = grid_samples_dir_factor_y_bc * np.expand_dims(orthogonal_b, axis=0)
    grid_samples = center_plane + grid_samples_x + grid_samples_y

    # debug
    # grid_nodes_dir_factor_x_bc = np.repeat(np.expand_dims(xx.flatten(), 1), 3, axis=1)
    # grid_nodes_dir_factor_y_bc = np.repeat(np.expand_dims(yy.flatten(), 1), 3, axis=1)
    # grid_nodes_x = grid_nodes_dir_factor_x_bc * np.expand_dims(orthogonal_a, axis=0)
    # grid_nodes_y = grid_nodes_dir_factor_y_bc * np.expand_dims(orthogonal_b, axis=0)
    # grid_nodes = center_plane + grid_nodes_x + grid_nodes_y
    # mesh_io.write_xyz("grid.xyz", grid_nodes)

    # filter points that are outside the patch (unit sphere)
    plane_centers = np.broadcast_to(center_plane, grid_samples.shape)
    points_in_patch = utils.cartesian_dist(grid_samples, plane_centers) < 1.0
    patch_samples = grid_samples[points_in_patch]

    return patch_samples


if __name__ == "__main__":
    import mesh_io

    sampling_dist = 0.1
    plane_dist = 0.3
    points, plane_index = make_patch(sampling_dist=sampling_dist, plane_dist=plane_dist)

    mesh_io.write_xyz("test.xyz", points)
