Thank you for reviewing!

This supplementary material includes:
- supplementary material containing additional qualitative and quantitative results (e.g. on a new, mostly organic test set based on Thingi10k)
- an Excel sheet with detailed Chamfer distances for each shape in all datasets.
- some meshes and renderings of the reconstructions.
- the source code (Python 3, PyTorch, create a conda environment using the meshnet.yml).
- the pre-trained model.
- a minimal functional sample of the dataset.

We are happy to provide more data when requested and help with the setup-up.

To process a dataset for training or evaluation, put (more) meshes 
in ./meshnet_code/datasets/implicit_surf_14/00_base_meshes/
in .off, .ply or .stl format.
The meshes must be watertight when used for training.
Set 'only_for_evaluation = 1' in the settings.ini for pure evaluation datasets.
Download BlenSor (https://www.blensor.org/pages/downloads.html) 
Change the path to the blensor binary in make_dataset.py

Run ./meshnet_code/make_dataset.py to process the dataset.
   A minimal set of 3 shapes is already provided.
Run ./meshnet_code/full_run.py for training and evaluation.
   When asked if you want to overwrite the existing training run, you can enter 'n' to skip training and proceed with evaluation.

Models will appear in ./meshnet_code/models, a pre-trained model is provided.
Results will appear in ./meshnet_code/results

Note: 'MeshNet' was the initial title for this work and appears in multiple places.